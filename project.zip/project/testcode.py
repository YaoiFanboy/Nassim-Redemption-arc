from new_classes import Patient
from new_classes import Timer
from new_classes import ICU

import unittest
import io
from unittest.mock import patch


class TestPatient(unittest.TestCase):
    def setUp(self):
        self.patient = Patient(isPlanned=True, hoursToGo=72, afdeling='NEU')
        self.patient2 = Patient(isPlanned=False, hoursToGo=-10, afdeling='CHIR')

    def test_get_afdeling(self):
        self.assertEqual(self.patient.get_afdeling(), 'NEU')

    def test_get_reschedule_count(self):
        self.assertEqual(self.patient.get_reschedule_count(), 0)

    def test_print_self(self):
        with unittest.mock.patch('sys.stdout', new=io.StringIO()) as fake_stdout:
            self.patient.print_self()
            output = fake_stdout.getvalue().strip()
            self.assertEqual(output, 'patient is planned True\npatient stay length 72 hours\npatient afdeling NEU')

    def test_info(self):
        self.assertEqual(self.patient.info(), ['NEU', 72, 0, True, 6])
        self.assertEqual(self.patient2.info(), ['CHIR', -10, 0, False, 6])


class TestTimer(unittest.TestCase):
    def setUp(self):
        self.timer = Timer(time=0, stepsize_hour=1, run_time_hour=24)

    def test_count_time(self):
        self.timer.count_time()
        self.assertEqual(self.timer.get_time(), 1)

    def test_get_time(self):
        self.assertEqual(self.timer.get_time(), 0)

    def test_get_run_time_hour(self):
        self.assertEqual(self.timer.get_run_time_hour(), 24)


class TestICU(unittest.TestCase):

    def setUp(self):
        self.icu = ICU(5, 6)
        self.patient1 = [1, 3, 0, True]
        self.patient2 = [2, 2, 0, False]
        self.patient3 = [3, 1, 0, True]
        self.patient4 = [4, 2, 5, True]
        self.patient7 = Patient(isPlanned=True, hoursToGo=2, afdeling='NEU').info()
        self.patient8 = Patient(isPlanned=True, hoursToGo=12, afdeling='NEU').info()
        self.patient9 = ["NEU", 10, 2, False, 2]
        self.patient10 = ["CHIR", 10, 7, False, 4]

    def test_get_available_beds(self):
        self.icu.add_patient(self.patient1)
        self.assertEqual(self.icu.get_available_beds(), 4)
        self.icu.add_patient(self.patient2)
        self.assertEqual(self.icu.get_available_beds(), 3)

    def test_add_patient(self):
        self.icu.add_patient(self.patient1)
        self.assertEqual(self.icu.bedden, [[1, 3, 0, True]])
        self.icu.add_patient(self.patient2)
        self.assertEqual(self.icu.bedden, [[1, 3, 0, True], [2, 2, 0, False]])

    def test_add_patient_waitlist(self):
        self.icu.add_patient_waitlist(self.patient1)
        self.assertEqual(self.icu.waitlist, [[1, 3, 0, True]])
        self.icu.add_patient_waitlist(self.patient2)
        self.assertEqual(self.icu.waitlist, [[1, 3, 0, True], [2, 2, 0, False]])

    def test_count_patient_time(self):
        self.icu.add_patient(self.patient9)
        self.icu.add_patient_waitlist(self.patient10)
        self.icu.count_patient_time(3)
        self.assertEqual(self.icu.bedden[0], ["NEU", 7, 2, False, 2])
        self.assertEqual(self.icu.waitlist[0], ["CHIR", 10, 7, False, 1])

    def test_recount_beds(self):
        self.icu.add_patient(self.patient7)
        self.icu.add_patient(self.patient8)
        self.icu.count_patient_time(5)
        self.icu.recount_beds()
        self.assertEqual(len(self.icu.bedden), 1)
        self.assertEqual(self.icu.bedden[0], ['NEU', 7, 0, True, 6])

    def test_reschedule_rule_updater(self):
        self.icu.add_patient_waitlist(self.patient9)
        self.icu.add_patient_waitlist(self.patient10)
        self.icu.count_patient_time(3)
        self.icu.reschedule_rule_updater()
        self.assertEqual(self.icu.waitlist[0][4], 6)
        self.assertEqual(self.icu.waitlist[0][2], 3)
        #check if patient10 got removed
        self.assertEqual(self.icu.waitlist[0], ['NEU', 10, 3, False, 6])

    #moet deze doen met een seed
    def test_final_stats(self):
        return

    def test_waitlist_to_bedden(self):
        self.icu.add_patient(self.patient9)
        self.icu.add_patient_waitlist(self.patient10)
        self.icu.waitlist_to_bedden()
        self.assertEqual(len(self.icu.bedden), 2)
        self.assertEqual(self.icu.bedden[1], ["CHIR", 10, 7, False, 4])

    def test_schedule(self):
        return


unittest.main()