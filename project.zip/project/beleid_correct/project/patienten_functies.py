from random import randint
import numpy as np

def patient():
    dag = patient_weekday()
    tijd = patient_time()
    afdeling = patient_afdeling()
    hoursZiek = patient_duration()
    planned = patient_planned()

    return planned, hoursZiek, afdeling, dag, tijd

# afdelingen
def patient_amount(multiplier=0, multiply=False):
    aantallen = [0,1,2,3,4,5,6,7,8,9,10,11,12,13]
    kansen = [0.1777535441657579,0.062159214830970554,0.0970556161395856,0.08724100327153762,0.11232279171210469,0.11123227917121047,0.11995637949836423,0.08833151581243184,0.07415485278080698,0.03925845147219193,0.015267175572519083,0.007633587786259542,0.0054525627044711015,0.0021810250817884407]
    if multiply:
        aantallen = [getal * multiplier for getal in aantallen]
    x = np.random.choice(aantallen, 1, p=kansen)
    return x[0]

def patient_time():
    times = ["00:00", "06:00", "12:00", "18:00"]
    time = np.random.choice(times, 1, p=[0.202, 0.102, 0.451, 0.245])
    return time[0]

def patient_weekday():
    days = [1, 2, 3, 4, 5, 6, 7]
    day = np.random.choice(days, 1, p=[0.165, 0.159, 0.153, 0.171, 0.162, 0.090, 0.100])
    return day[0]

def patient_planned():
    plan = [True, False]
    pln = np.random.choice(plan, 1, p=[0.333, 0.667])
    return pln[0]

def patient_afdeling():
    afdelingen = ["CAPU", "CARD", "CHIR", "INT", "NEC", "NEU", "OTHER"]
    afd = np.random.choice(afdelingen, 1, p=[0.335, 0.077, 0.133, 0.255, 0.082, 0.105, 0.013])
    return afd[0]
    
def patient_duration():
    tijdblok = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    blok = np.random.choice(tijdblok, 1, p=[0.132, 0.177, 0.127, 0.099, 0.063, 0.057, 0.082, 0.090, 0.112, 0.061])
    return blok_naar_tijd(blok)

def blok_naar_tijd(blok):
    blokint = int(blok[0])

    if blokint == 1:
        return randint(1, 9)
    elif blokint == 2:
        return randint(8, 17)
    elif blokint == 3:
        return randint(16, 25)
    elif blokint == 4:
        return randint(24, 33)
    elif blokint == 5:
        return randint(32, 41)
    elif blokint == 6:
        return randint(40, 49)
    elif blokint == 7:
        return randint(48, 65)
    elif blokint == 8:
        return randint(64, 97)
    elif blokint == 9:
        return randint(96, 201)
    elif blokint == 10:
        return randint(200, 401)
        