class ICU():
    def __init__(self, max_reschedule, aantallen):
        #lijsten voor patienten
        self.afdelingen = {'CAPU': [[], aantallen[0]], 'CIO': [[], aantallen[1]], 'CHIR': [[], aantallen[2]], 'NN': [[],aantallen[3]]}
        self.waitlist = []
        
        self.patients_denied = 0
        self.patients_rescheduled = 0
        self.patients_helped = 0
        self.reschedule_succes = 0
        
        self.max_reschedule_amount = max_reschedule


    def get_available_beds(self, afdeling):
        return self.afdelingen[afdeling][1] - len(self.afdelingen[afdeling][0])

    def add_patient(self, patient, afdeling):
        self.afdelingen[afdeling][0].append(patient)

    def add_patient_waitlist(self, patient):
        self.waitlist.append(patient)
    
    def count_patient_time(self,timer_time):
        '''
        Doet de tijd van elke soort patient eraf
        '''

        for afdeling, patienten in self.afdelingen.items():
            for patient in patienten[0]:
                #print(patient)
                patient[1] -= timer_time

        for waiting_patient in self.waitlist:
            waiting_patient[4] -= timer_time


    def recount_beds(self):
        '''
        Update de lijst van patienten
        '''
        for afdeling, lijsten in self.afdelingen.items():
            lijsten[0] = [patient for patient in lijsten[0] if patient[1] > 0]
       # self.bedden = [patienten[0] for patienten in self.afdelingen.items() if patienten[1] > 0]

    def reschedule_rule_updater(self):
        before = len(self.waitlist)
        for waiting_patient in self.waitlist:
            if waiting_patient[4] == 0:                  # Schedule cooldown minder dan 0
                waiting_patient[4] = 36                   # HIER MOET SELF.RESCHEDULE_COOLDOWN
                waiting_patient[2] += 1

        self.waitlist = [p for p in self.waitlist if p[2] <= self.max_reschedule_amount]
        after = len(self.waitlist)
        self.patients_denied += before - after

    def final_stats(self):
        print("patients denied: " + str(self.patients_denied))
        print("patients geholpen: " + str(self.patients_helped))
        print("patients gerescheduled: " + str(self.patients_rescheduled))
        print(f"reschedule succes: {self.reschedule_succes}")
        print(f"aantal pattienten op waitinglist: {len(self.waitlist)}\n")
        

    def waitlist_to_bedden(self):
        '''
        Patienten van de waitlist naar de mainlist
        '''   
        if len(self.waitlist) > 0:
            if self.waitlist[0][0] in ['CARD','INT','OTHER']:
                afdeling = 'CIO'
            elif self.waitlist[0][0] in ['NEC','NEU']:
                afdeling = 'NN'
            else:
                afdeling = self.waitlist[0][0]

            if self.get_available_beds(afdeling) > 0:                 # Er zijn dus bedden beschikbaar en # Checken of er patienten in de waitlist zitten
                self.add_patient(self.waitlist[0], afdeling)                                                              
                self.waitlist.pop(0)
                self.patients_helped += 1
                self.reschedule_succes += 1
        return

# [self.afdeling, self.hoursToGo, self.reschedule_count, self.isPlanned, self.reschedule_cooldown, self.weekday, self.time]
    def schedule(self, patient):
        '''
        Zet de patienten in verschillende lijsten of denied ze
        '''
        #if planned
        if patient[0] in ['CARD','INT','OTHER']:
            afdeling = 'CIO'
        elif patient[0] in ['NEC','NEU']:
            afdeling = 'NN'
        else:
            afdeling = patient[0]

        if patient[3]:
            #check if plek
            if self.get_available_beds(afdeling) > 0:
                self.add_patient(patient, afdeling)
                self.patients_helped += 1
            
            #no plek en ze zijn minder dan 6 keer rescheduled dan in waitlist
            #checken of patient rescheduled kan worden
            elif patient[2] < self.max_reschedule_amount:
                patient[2] += 1

                #patient zit in de waitlists
                self.add_patient_waitlist(patient)
                self.patients_rescheduled += 1
                
            #maxed reschedules berijkt
            else:
                self.patients_denied +=1
        
        #unplanned
        else:
            #check if plek
            if self.get_available_beds(afdeling) > 0:
                self.add_patient(patient, afdeling)
                self.patients_helped += 1

            #geen plek en unplanned patient
            else:
                self.patients_denied +=1