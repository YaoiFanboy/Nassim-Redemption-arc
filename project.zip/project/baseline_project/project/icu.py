class ICU():
    def __init__(self, bedcount, max_reschedule):

        #hoeveel bedden er NU beschikbaar zijn
        self.bedcount = bedcount

        #deze staat vast als een getal om te kijken hoeveel max bedden er zijn
        self.max_bedcount = bedcount

        #lijsten voor patienten
        self.bedden = []
        self.waitlist = []
        
        self.patients_denied = 0
        self.patients_rescheduled = 0
        self.patients_helped = 0
        self.reschedule_succes = 0
        
        self.max_reschedule_amount = max_reschedule


    def get_available_beds(self):
        return self.bedcount - len(self.bedden)

    def add_patient(self, patient):
        self.bedden.append(patient)

    def add_patient_waitlist(self, patient):
        self.waitlist.append(patient)
    
    def count_patient_time(self,timer_time):
        '''
        Doet de tijd van elke soort patient eraf
        '''

        for patient in self.bedden:
            patient[1] -= timer_time

        for waiting_patient in self.waitlist:
            waiting_patient[4] -= timer_time


    def recount_beds(self):
        '''
        Update de lijst van patienten
        '''
        self.bedden = [patient for patient in self.bedden if patient[1] > 0]

    def reschedule_rule_updater(self):
        before = len(self.waitlist)
        for waiting_patient in self.waitlist:
            if waiting_patient[4] == 0:                  # Schedule cooldown minder dan 0
                waiting_patient[4] = 36                   # HIER MOET SELF.RESCHEDULE_COOLDOWN
                waiting_patient[2] += 1

        self.waitlist = [p for p in self.waitlist if p[2] <= self.max_reschedule_amount]
        after = len(self.waitlist)
        self.patients_denied += before - after

    def final_stats(self):
        print("patients denied: " + str(self.patients_denied))
        print("patients geholpen: " + str(self.patients_helped))
        print("patients gerescheduled: " + str(self.patients_rescheduled))
        print(f"reschedule succes: {self.reschedule_succes}")
        print(f"aantal pattienten op waitinglist: {len(self.waitlist)}\n")
        

    def waitlist_to_bedden(self):
        '''
        Patienten van de waitlist naar de mainlist
        '''   
        if self.get_available_beds() > 0 and len(self.waitlist) > 0:                 # Er zijn dus bedden beschikbaar en # Checken of er patienten in de waitlist zitten
            self.add_patient(self.waitlist[0])                                                              
            self.waitlist.pop(0)
            self.patients_helped += 1
            self.reschedule_succes += 1
        return


    def schedule(self, patient):
        '''
        Zet de patienten in verschillende lijsten of denied ze
        '''
        #if planned
        if patient[3]:

            #check if plek
            if self.get_available_beds() > 0:
                self.add_patient(patient)
                self.patients_helped += 1
            
            #no plek en ze zijn minder dan 6 keer rescheduled dan in waitlist
            #checken of patient rescheduled kan worden
            elif patient[2] < self.max_reschedule_amount:
                patient[2] += 1

                #patient zit in de waitlists
                self.add_patient_waitlist(patient)
                self.patients_rescheduled += 1
                
            #maxed reschedules berijkt
            else:
                self.patients_denied +=1
        
        #unplanned
        else:
            #check if plek
            if self.get_available_beds() > 0:
                self.add_patient(patient)
                self.patients_helped += 1

            #geen plek en unplanned patient
            else:
                self.patients_denied +=1