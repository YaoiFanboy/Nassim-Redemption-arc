from icu import ICU
import patienten_functies as pf

class Patient():
    def __init__(self, isPlanned, hoursToGo, afdeling, weekday, time):
        self.afdeling = afdeling
        self.hoursToGo  = hoursToGo
        self.isPlanned = isPlanned
        self.time = time
        self.weekday = weekday
        self.reschedule_count = 0

        #ze mogen pas na +6 uur weer opnieuw gerescheduled worden, maar er word wel constant gekeken of er plek is 
        self.reschedule_cooldown = 36
        self.can_be_rescheduled  = True

    def get_afdeling(self):
        return self.afdeling

    def get_reschedule_count(self):
        return self.reschedule_count

    def print_self(self):
        print('patient is planned ' + str(self.isPlanned))
        print('patient stay length ' + str(self.hoursToGo) + " hours") 
        print('patient afdeling ' + str(self.afdeling))

    def info(self):
        return [self.afdeling, self.hoursToGo, self.reschedule_count, self.isPlanned, self.reschedule_cooldown, self.weekday, self.time]


class Timer():
    def __init__(self, stepsize_hour, dag, uur):
        self.stepsize_hour = stepsize_hour
        self.dag = dag
        self.uur = uur
        self.indicator = 0
        self.loop_count = 0
        self.uren = ['00:00','06:00','12:00','18:00']

    def get_uur(self):
        return self.uur

    def count_uur(self):
        self.uur = self.uren[self.indicator]
        self.indicator += 1
        self.loop_count += 1
        if self.indicator == 4:
            self.dag + 1
            self.indicator = 0
    
    def get_loop_c(self):
        return self.loop_count

    def get_dag(self):
        return self.dag


def test_loop():
    icu = ICU(28, 4)

    # 104 weken
    for i in range(104):
        timer = Timer(6, 1, 0)
        patients = week()

        # dit moet een week simuleren
        # 6 uur * 7 dagen
        while timer.get_loop_c() < 28:
            icu.waitlist_to_bedden()
            dag = timer.get_dag()
            tijd = timer.get_uur()

            for patient in patients:
                if patient[5] == dag and patient[6] == tijd:
                    icu.schedule(patient)

            icu.reschedule_rule_updater()
            timer.count_uur()
            icu.count_patient_time(timer.stepsize_hour)
            icu.recount_beds()
    
    icu.final_stats()

def week():
    week_lijst = []
    for i in range(7):
        dag_patients = dag()
        for patient in dag_patients:
            week_lijst.append(patient)
    return week_lijst

def dag():
    patient_lijst = []
    aantal_patients = pf.patient_amount()

    for patient in range(aantal_patients):
        patient_lijst.append(Patient(pf.patient_planned(), pf.patient_duration(), pf.patient_afdeling(), pf.patient_weekday(), pf.patient_time()).info())
    
    return patient_lijst

#test_loop()