from new_classes import week

print(week())